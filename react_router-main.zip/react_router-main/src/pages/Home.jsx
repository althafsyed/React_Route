// src/pages/Home.jsx
const Home = () => {
  return (
    <div>
      <h1>Welcome to the Air Ticket Booking System</h1>
      <p>Find the best flight deals here. Book your tickets in real-time.</p>
    </div>
  );
};

export default Home;
